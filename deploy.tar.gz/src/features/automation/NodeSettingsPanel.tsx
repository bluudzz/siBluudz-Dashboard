import { useEffect, useState } from 'react'
import { X, Play, Trash2, Pin, Copy, Check, Pencil } from 'lucide-react'
import type { Edge } from '@xyflow/react'
import { formatModelLabel, workflowRequest, type StudioNode, type RunItem } from './workflow-model'
import { agentResources, isSubNode } from '../../../shared/workflow-connections'
import type { DataItem } from '../../../shared/workflow-engine'
import { SimpleDataEditor, dataLabel, friendlyPrompt, technicalPrompt } from './SimpleDataEditor'
import { InstagramAccountSettings } from './InstagramAccountSettings'
import { WorkflowDataViewer } from './WorkflowDataViewer'

const nodeHelp:Record<string,string>={trigger:'Tentukan bahan awal, seperti topik, produk, dan audiens. Langkah berikutnya akan memakai bahan ini.',promptTrigger:'Mulai alur dari perintah teks. Mode Normal meneruskan teks; mode AI mengirim hasil model ke langkah berikutnya.',chatTrigger:'Mulai percakapan dengan AI. Pesan yang dikirim lewat Uji chat akan menjadi tugas untuk agent.',aiAgent:'Tulis tugas AI, lalu pilih model, Memory, dan Tools yang diperlukan.',chatModel:'Pilih AI yang akan mengerjakan tugas. Model ini memakai koneksi 9router Anda.',memory:'Menyimpan pesan sebelumnya agar AI Agent memahami konteks percakapan.',tool:'Memberi kemampuan tambahan kepada AI Agent saat mengerjakan tugas.',set:'Tambahkan atau ubah informasi sebelum diteruskan ke langkah berikutnya.',splitOut:'Membagi hasil langsung dari AI Agent menjadi beberapa item sesuai jumlah yang dipilih.',if:'Tentukan kapan alur dilanjutkan ke cabang Ya atau Tidak.',approval:'Tinjau hasil yang masuk sebelum langkah berikutnya dapat berjalan.',searchContent:'Cari berita terbaru dari Google News berdasarkan topik konten Anda.',httpRequest:'Ambil teks atau JSON dari alamat HTTPS publik dengan metode GET.',imageGenerate:'Buat gambar dari prompt menggunakan model gambar 9router.',instagram:'Terbitkan gambar, carousel, Reel, atau Story; baca komentar; atau lihat statistik akun Instagram profesional.'}
const optionNames:Record<string,string>={manual:'Saat tombol jalankan ditekan',schedule:'Sesuai jadwal (belum aktif)',preview:'Coba rencana saja',live:'Gunakan AI terhubung',knowledge:'Baca brief atau pengetahuan',textLength:'Hitung karakter dan kata',equals:'Sama dengan',contains:'Mengandung kata',exists:'Sudah terisi',carousel:'Beberapa slide (carousel)',single:'Satu gambar',publish:'Terbitkan gambar / carousel',reels:'Terbitkan Reel',stories:'Terbitkan Story',comments:'Baca komentar',insights:'Lihat statistik',list:'Lihat post terbaru',inspect:'Periksa satu post','Input dari node sebelumnya':'Bahan dari langkah sebelumnya'}
const splitOutAgentRule=(count:number)=>`Buat tepat ${count} prompt gambar untuk carousel Instagram.\n\nBalas HANYA dengan JSON valid tanpa markdown, tanpa tanda \`\`\` dan tanpa penjelasan tambahan.\n\nGunakan format ini:\n{\n  "prompts": [\n${Array.from({length:count},(_,index)=>`    {"slide": ${index+1}, "role": "content", "prompt": "..."}${index===count-1?'':','}`).join('\\n')}\n  ]\n}\n\nPastikan jumlah prompt tepat ${count}. Setiap prompt harus berbeda, lengkap, dan siap digunakan untuk membuat gambar.`
export function DataViewer({items}:{items:DataItem[]}) {
  return <WorkflowDataViewer items={items}/>
}

interface NodePanelProps {
  workflowId:string
  node:StudioNode
  nodes:StudioNode[]
  edges:Edge[]
  busy:boolean
  onUpdate:(id:string,data:StudioNode['data'])=>void
  onDelete:(id:string)=>void
  onClose:()=>void
  onExecute:(id:string)=>void
  onSelect:(id:string)=>void
  onAddResource:(type:string,id:string)=>void
}
export function NodeSettingsPanel({workflowId,node,nodes,edges,busy,onUpdate,onDelete,onClose,onExecute,onSelect,onAddResource}:NodePanelProps) {
  const [tab,setTab]=useState('parameters')
  const [advanced,setAdvanced]=useState(false)
  const [modelIds,setModelIds]=useState<string[]>([])
  const [imageModelIds,setImageModelIds]=useState<string[]>([])
  const [editingLabel,setEditingLabel]=useState(false)
  const [labelDraft,setLabelDraft]=useState(String(node.data.label||''))
  const [ruleCopied,setRuleCopied]=useState(false)
  const [reviewedInput,setReviewedInput]=useState<DataItem[]>([])
  useEffect(()=>{
    if(node.type!=='approval'||node.data.approvedItems!=null||node.data.result?.input?.length)return
    let cancelled=false
    workflowRequest<{runs:RunItem[]}>(`/${workflowId}/runs`).then(({runs})=>{
      const pending=runs.find(run=>run.result?.nodeResults?.[node.id]?.status==='waiting')?.result?.nodeResults?.[node.id]?.input
      if(!cancelled&&Array.isArray(pending))setReviewedInput(pending)
    }).catch(()=>{})
    return()=>{cancelled=true}
  },[workflowId,node.id,node.type,node.data.approvedItems,node.data.result])
  useEffect(()=>{
    if(!['aiAgent','chatModel','promptTrigger'].includes(node.type||''))return
    let cancelled=false
    fetch('/api/ai/status',{credentials:'same-origin'}).then(r=>r.ok?r.json():{}).then((data:{availableModels?:string[]})=>{if(!cancelled)setModelIds(data.availableModels||[])}).catch(()=>{})
    return()=>{cancelled=true}
  },[node.type])
  useEffect(()=>{
    if(node.type!=='imageGenerate')return
    let cancelled=false
    fetch('/api/ai/image-models',{credentials:'same-origin'}).then(response=>response.ok?response.json():{}).then((body:{models?:string[];defaultModel?:string})=>{
      if(cancelled)return
      setImageModelIds(body.models||[])
      if(!node.data.model&&body.defaultModel)onUpdate(node.id,{...node.data,model:body.defaultModel})
    }).catch(()=>{})
    return()=>{cancelled=true}
  },[node.id,node.type])
  useEffect(()=>{setEditingLabel(false);setLabelDraft(String(node.data.label||''))},[node.id])
  const data=node.data
  const isModelNode=node.type==='chatModel'
  const resources=agentResources(node.id,nodes,edges)
  const result=data.result
  const approvalInput=result?.status==='waiting'&&result.input?.length?result.input:reviewedInput
  const upstream=new Set<string>()
  const collectUpstream=(id:string)=>{if(upstream.has(id))return;upstream.add(id);edges.filter(edge=>edge.target===id).forEach(edge=>collectUpstream(edge.source))}
  collectUpstream(node.id)
  const availableKeys=[...new Set([...(result?.input?.[0]?Object.keys(result.input[0].json):[]),...nodes.filter(item=>upstream.has(item.id)&&item.id!==node.id).flatMap(item=>{
    if(item.type==='chatTrigger')return ['chatInput','sessionId']
    if(item.type==='aiAgent')return ['output']
    try{return Object.keys(JSON.parse(String(item.data.sampleData||item.data.fields||'{}')))}catch{return []}
  })])]
  const str=(key:string)=>typeof data[key]==='string'?data[key] as string:''
  const update=(key:string,value:unknown)=>onUpdate(node.id,{...data,[key]:value})
  const commitLabel=()=>{const next=labelDraft.trim();if(next&&next!==String(data.label||''))update('label',next);else if(!next)setLabelDraft(String(data.label||''));setEditingLabel(false)}
  const splitCount=Math.min(20,Math.max(1,Number(data.splitCount)||3))
  const copySplitRule=async()=>{try{await navigator.clipboard.writeText(splitOutAgentRule(splitCount));setRuleCopied(true)}catch{setRuleCopied(false)}}
  const field=(key:string,label:string,placeholder='',multiline=false)=><label className="wf-field" key={key}><span>{label}</span>{multiline?<textarea rows={key==='fields'||key==='sampleData'?5:3} value={str(key)} disabled={busy} placeholder={placeholder} onChange={e=>update(key,e.target.value)}/>:<input value={str(key)} disabled={busy} placeholder={placeholder} onChange={e=>update(key,e.target.value)}/>}</label>
  const choice=(key:string,label:string,options:string[])=><label className="wf-field"><span>{label}</span><select disabled={busy} value={str(key)||options[0]} onChange={e=>update(key,e.target.value)}>{options.map(option=><option key={option} value={option}>{optionNames[option]||option}</option>)}</select></label>
  const checkbox=(key:string,label:string,checked=Boolean(data[key]))=><label className="wf-check"><input type="checkbox" disabled={busy} checked={checked} onChange={e=>update(key,e.target.checked)}/>{label}</label>
  return <aside aria-label="Detail node" className={'wf-node-dialog '+(isModelNode?'wf-model-dialog':'')} onKeyDown={e=>{if(e.key==='Escape'&&!busy){e.stopPropagation();onClose()}}}>
     <header className="wf-dialog-heading"><div className="wf-dialog-title"><div className="wf-node-title-row">{editingLabel?<input className="wf-node-title-input" autoFocus disabled={busy} value={labelDraft} onChange={event=>setLabelDraft(event.target.value)} onBlur={commitLabel} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();commitLabel()}if(event.key==='Escape'){setLabelDraft(String(data.label||''));setEditingLabel(false)}}}/>:<h2>{String(data.label||'Node')}</h2>}<button type="button" className="wf-node-title-edit" disabled={busy} aria-label="Ganti nama node" title="Ganti nama node" onClick={()=>{setLabelDraft(String(data.label||''));setEditingLabel(true)}}><Pencil size={14}/></button></div><p>{isModelNode?'Pilih model yang akan digunakan oleh AI Agent.':nodeHelp[node.type||'']||'Atur langkah ini sesuai tujuan workflow Anda.'}</p></div><div className="wf-dialog-heading-actions">{!isModelNode&&<button disabled={busy||isSubNode(node.type)} onClick={()=>{setTab('results');onExecute(node.id)}}><Play size={15}/>{busy?'Menguji…':'Uji langkah'}</button>}</div><button className="wf-dialog-close" disabled={busy} aria-label="Tutup detail node" onClick={onClose}><X size={18}/></button></header>
    {!isModelNode&&<nav className="wf-detail-tabs" aria-label="Bagian detail node">{[['parameters','Pengaturan'],['results','Hasil uji']].map(([id,label])=><button key={id} aria-pressed={tab===id} onClick={()=>setTab(id)}>{label}</button>)}</nav>}
    <div className="wf-node-columns">
      {isModelNode?<section className="wf-parameters wf-model-settings is-current"><label className="wf-field"><span>Pilih model AI</span>{modelIds.length>0?<select autoFocus disabled={busy} value={str('model')} onChange={event=>update('model',event.target.value)}><option value="">Pilih model…</option>{str('model')&&!modelIds.includes(str('model'))&&<option value={str('model')}>{formatModelLabel(str('model'))}</option>}{modelIds.map(id=><option key={id} value={id}>{formatModelLabel(id)}</option>)}</select>:<input autoFocus list="wf-chat-models" disabled={busy} value={str('model')} placeholder="Masukkan ID model AI" onChange={event=>update('model',event.target.value)}/>}</label>{modelIds.length===0&&<p className="wf-inline-note">Daftar model belum tersedia. Anda dapat memasukkan ID model secara manual.</p>}</section>:<>
      <section className={'wf-parameters '+(tab==='parameters'?'is-current':'')}>
        {node.type==='chatTrigger'&&<>{field('chatInput','Pesan untuk mencoba','Bantu saya membuat konten',true)}<p className="wf-inline-note">Untuk bercakap-cakap, klik Uji chat di toolbar lalu kirim pesan.</p>{advanced&&field('sessionId','ID sesi contoh','test-session')}</>}
        {node.type==='promptTrigger'&&<><label className="wf-field"><span>Perintah untuk memulai alur</span><textarea rows={6} value={str('prompt')} disabled={busy} placeholder="Contoh: Buat konsep 3 slide Instagram tentang produk saya, dengan rasio 4:5." onChange={event=>update('prompt',event.target.value)}/></label><label className="wf-field"><span>Cara menjalankan</span><select disabled={busy} value={str('promptMode')||'ai'} onChange={event=>update('promptMode',event.target.value)}><option value="ai">AI · kerjakan perintah dulu</option><option value="normal">Normal · teruskan perintah</option></select></label>{(str('promptMode')||'ai')==='ai'&&<label className="wf-field"><span>Model AI 9router</span>{modelIds.length?<select disabled={busy} value={str('model')} onChange={event=>update('model',event.target.value)}><option value="">Model utama 9router (otomatis)</option>{str('model')&&!modelIds.includes(str('model'))&&<option value={str('model')}>{formatModelLabel(str('model'))}</option>}{modelIds.map(id=><option key={id} value={id}>{formatModelLabel(id)}</option>)}</select>:<input disabled={busy} value={str('model')} placeholder="Kosong = model utama 9router" onChange={event=>update('model',event.target.value)}/>}</label>}<p className="wf-muted">Hasil dikirim sebagai prompt ke node berikutnya saat Anda menjalankan alur.</p></>}
        {node.type==='chatModel'&&<><label className="wf-field"><span>Model teks 9router</span>{modelIds.length>0?<select disabled={busy} value={str('model')} onChange={event=>update('model',event.target.value)}><option value="">Pilih model teks…</option>{str('model')&&!modelIds.includes(str('model'))&&<option value={str('model')}>{formatModelLabel(str('model'))}</option>}{modelIds.map(id=><option key={id} value={id}>{formatModelLabel(id)}</option>)}</select>:<><input list="wf-chat-models" disabled={busy} value={str('model')} placeholder="Pilih model yang mendukung tool calling" onChange={event=>update('model',event.target.value)}/><datalist id="wf-chat-models">{modelIds.map(id=><option key={id} value={id} label={formatModelLabel(id)}>{formatModelLabel(id)}</option>)}</datalist></>}</label>{advanced&&choice('temperature','Variasi jawaban (temperature)',['0.7','0','0.2','1'])}<p className="wf-inline-note">Model harus mendukung tool calling. Kredensial memakai koneksi 9router dashboard. Sub-node ini dijalankan melalui AI Agent.</p></>}
        {node.type==='memory'&&<>{choice('windowSize','Berapa percakapan terakhir yang diingat?',['5','10','20','1'])}<p className="wf-inline-note">Percakapan dalam sesi yang sama akan diingat. Klik Sesi baru di Uji chat untuk memulai dari awal.</p>{advanced&&field('sessionKey','Kunci sesi','{{ $json.sessionId }}')}</>}
         {node.type==='tool'&&<>{choice('toolType','Kemampuan yang diberikan',['knowledge','textLength'])}{field('description','Kapan Tools digunakan?','Gunakan brief atau hitung panjang teks saat diperlukan',true)}{str('toolType')==='knowledge'&&field('content','Isi brief / pengetahuan','Isi produk, audiens, gaya bahasa, batasan dan CTA.',true)}<p className="wf-inline-note">AI akan memilih kapan perlu memakai Tools saat mengerjakan tugas.</p></>}
          {node.type==='splitOut'&&<><p className="wf-inline-note">Hubungkan langsung setelah AI Agent. Jumlah ini otomatis menjadi instruksi untuk AI Agent dan setiap hasil harus berisi tepat jumlah item tersebut.</p>{choice('splitCount','Jumlah output',['3','1','2','4','5','6','7','8','9','10','15','20'])}<p className="wf-muted">Input hanya dibaca dari kolom output AI Agent dengan daftar prompts.</p><section className="wf-copy-rule"><h3>Aturan tambahan untuk AI Agent</h3><p className="wf-muted">Aturan ini sudah mengikuti jumlah output di atas. Salin lalu tempel ke kolom “Tugas AI” pada AI Agent.</p><textarea readOnly rows={11} value={splitOutAgentRule(splitCount)}/><button type="button" onClick={()=>void copySplitRule()}>{ruleCopied?<Check size={14}/>:<Copy size={14}/>} {ruleCopied?'Aturan tersalin':'Salin aturan'}</button></section></>}
          {node.type==='aiAgent'&&<>{str('executionMode')!=='live'&&<p className="wf-inline-note">Langkah lama ini masih pratinjau. <button disabled={busy} onClick={()=>update('executionMode','live')}>Aktifkan AI terhubung</button></p>}{advanced&&choice('executionMode','Cara menjalankan langkah ini',['preview','live'])}<label className="wf-field"><span>Tugas AI</span><textarea rows={5} value={advanced?str('aiPrompt'):friendlyPrompt(str('aiPrompt'))} disabled={busy} placeholder="Contoh: Buatkan caption Instagram berdasarkan topik, produk, audiens, dan CTA dari data sebelumnya." onChange={event=>update('aiPrompt',advanced?event.target.value:technicalPrompt(event.target.value,availableKeys))}/></label>{!advanced&&availableKeys.length>0&&<div className="wf-data-tokens"><span>Tambahkan bahan dari langkah sebelumnya:</span>{availableKeys.slice(0,10).map(key=><button type="button" key={key} disabled={busy} onClick={()=>update('aiPrompt',str('aiPrompt')+` {{ $json.${key} }}`)}>{dataLabel(key)}</button>)}<p>Teks dalam [kurung] diisi otomatis saat alur dijalankan.</p></div>}<details className="wf-advanced wf-ai-rules"><summary>Aturan AI</summary>{field('systemMessage','Aturan AI','Contoh: Kamu adalah asisten konten Instagram. Gunakan Bahasa Indonesia dan jangan mengarang fakta.',true)}</details>{advanced&&choice('maxIterations','Batas putaran kerja AI',['3','1','2','4','5'])}<div className="wf-resource-list"><h4>Yang dipakai AI untuk bekerja</h4>{[['chatModel','Model AI (wajib)',resources.model],['memory','Memory',resources.memory],['tool','Tools (opsional)',resources.tools[0]]].map(([type,label,resource])=><div key={String(type)}><span>{String(label)}</span>{resource&&typeof resource==='object'?<button disabled={busy} onClick={()=>onSelect(resource.id)}>{String(resource.data.label)}</button>:<button disabled={busy} onClick={()=>onAddResource(String(type),node.id)}>+ Tambah</button>}</div>)}{resources.tools.slice(1).map(tool=><button key={tool.id} disabled={busy} onClick={()=>onSelect(tool.id)}>{String(tool.data.label)}</button>)}</div></>}
        {node.type==='trigger'&&<>
          {advanced&&choice('triggerMode','Kapan alur dimulai?',['manual','schedule'])}
          {str('triggerMode')==='schedule'&&<>{field('interval','Rencana jadwal','Setiap hari 10:00 WIB')}{advanced&&field('cron','Cron','0 10 * * *')}<p className="wf-inline-note">Jadwal hanya konfigurasi. Scheduler otomatis belum terhubung; pengujian tetap dijalankan manual.</p></>}
          <h3>Bahan awal workflow</h3><SimpleDataEditor value={str('sampleData')||'{}'} disabled={busy} onChange={value=>update('sampleData',value)}/>
          <details className="wf-advanced"><summary>Edit data teknis</summary>{field('sampleData','Data JSON','{"topic":"Ide konten"}',true)}</details>
        </>}
        {node.type==='set'&&<><h3>Informasi yang ditambahkan</h3><SimpleDataEditor value={str('fields')||'{}'} disabled={busy} onChange={value=>update('fields',value)}/>{checkbox('keepInput','Tetap bawa informasi dari langkah sebelumnya',data.keepInput!==false)}<details className="wf-advanced"><summary>Edit data teknis</summary>{field('fields','Data JSON','{"title":"{{ $json.topic }}"}',true)}</details></>}
        {node.type==='if'&&<><label className="wf-field"><span>Informasi yang diperiksa</span><select disabled={busy} value={str('field')} onChange={event=>update('field',event.target.value)}>{[...new Set([str('field'),...availableKeys])].filter(Boolean).map(key=><option key={key} value={key}>{dataLabel(key)}</option>)}</select></label>{choice('operator','Syaratnya',['equals','contains','exists'])}{str('operator')!=='exists'&&(str('field')==='approved'?<label className="wf-field"><span>Nilai yang diharapkan</span><select disabled={busy} value={str('value')} onChange={event=>update('value',event.target.value)}><option value="true">Ya / Sudah disetujui</option><option value="false">Belum / Tidak</option></select></label>:field('value','Nilai yang diharapkan','Contoh: siap'))}<p className="wf-muted">Jika syarat terpenuhi, alur mengikuti cabang Ya. Jika tidak, alur mengikuti cabang Tidak.</p>{advanced&&field('field','Nama field / path teknis','approved')}</>}
        {node.type==='imageGenerate'&&<><label className="wf-field"><span>Model gambar</span>{imageModelIds.length?<select disabled={busy} value={str('model')} onChange={event=>update('model',event.target.value)}><option value="">Pilih model gambar…</option>{str('model')&&!imageModelIds.includes(str('model'))&&<option value={str('model')}>{formatModelLabel(str('model'))}</option>}{imageModelIds.map(id=><option key={id} value={id}>{formatModelLabel(id)}</option>)}</select>:<input value={str('model')} disabled={busy} onChange={event=>update('model',event.target.value)} placeholder="ID model gambar dari 9router"/>}</label>{field('prompt','Prompt gambar (opsional)','Kosong = gunakan prompt dari langkah sebelumnya',true)}<p className="wf-muted">Rasio dan ukuran ditentukan dalam prompt. Satu gambar dibuat untuk setiap item yang masuk.</p></>}
        {node.type==='instagram'&&<><InstagramAccountSettings value={str('accountId')} busy={busy} onChange={id=>update('accountId',id)} operation={str('operation')||'publish'} onOperationChange={operation=>update('operation',operation)}/>{str('operation')==='publish'&&<><p className="wf-inline-note">Gambar dan caption otomatis diambil dari langkah sebelumnya. Pastikan ada Persetujuan Manual sebelum node ini.</p><details className="wf-advanced"><summary>Ubah sumber gambar atau caption</summary>{field('caption','Caption khusus','Kosong = caption dari langkah sebelumnya',true)}{field('imageUrl','URL gambar khusus','Kosong = gambar dari langkah sebelumnya')}</details></>}{str('operation')==='inspect'&&field('mediaId','ID post (opsional)','Kosong = ID dari langkah sebelumnya')}</>}
        {node.type==='approval'&&<section className="wf-approval-panel"><h3>Persetujuan konten</h3>{Array.isArray(data.approvedItems)?<><p className="wf-inline-note">Versi yang disetujui tersimpan. Pengujian berikutnya akan meneruskan versi ini, meskipun langkah sebelumnya menghasilkan teks baru.</p><DataViewer items={data.approvedItems as DataItem[]}/><button type="button" disabled={busy} onClick={()=>update('approvedItems',null)}>Cabut persetujuan</button></>:<><p className="wf-inline-note">Jalankan alur untuk melihat bahan yang masuk. Langkah sesudah ini akan menunggu keputusan Anda.</p>{approvalInput.length?<><DataViewer items={approvalInput}/><button type="button" disabled={busy} onClick={()=>update('approvedItems',approvalInput)}>Setujui hasil ini</button><p className="wf-muted">Setelah menyetujui, jalankan ulang alur. Yang diteruskan adalah salinan persis dari hasil yang Anda tinjau.</p></>:<p className="wf-muted">Belum ada hasil untuk ditinjau. Klik Jalankan alur atau Uji langkah terlebih dahulu.</p>}</>}</section>}
        {node.type==='searchContent'&&<>{field('query','Topik pencarian (opsional)','Kosong = memakai topik dari langkah sebelumnya')}{choice('limit','Jumlah sumber',['5','3','10'])}<p className="wf-inline-note">Topik dikirim ke Google News saat diuji. Hasil berisi judul, tautan, tanggal, dan nama sumber; periksa fakta sebelum membuat konten.</p></>}
        {node.type==='httpRequest'&&<>{field('url','Alamat HTTPS publik','https://contoh.com/data.json')}<p className="wf-inline-note">Hanya GET. Respons teks atau JSON disimpan pada hasil uji dan riwayat. URL lokal, jaringan privat, kredensial di alamat, dan pengalihan tidak diizinkan.</p></>}
         {node.type==='aiAgent'&&<>
           {advanced&&str('executionMode')!=='live'&&<label className="wf-field"><span>Model teks (pratinjau lama)</span><input list="wf-model-ids" disabled={busy} value={str('aiModel')||str('model')} onChange={e=>onUpdate(node.id,{...data,aiModel:e.target.value,model:e.target.value})} placeholder="Pilih dari katalog atau ketik ID model"/><datalist id="wf-model-ids">{modelIds.map(id=><option key={id} value={id} label={formatModelLabel(id)}>{formatModelLabel(id)}</option>)}</datalist></label>}
          {node.type==='aiAgent'&&advanced&&field('role','Peran agent','Analyst')}
           {str('executionMode')!=='live'&&<p className="wf-inline-note">Mode pratinjau hanya menampilkan konfigurasi dan prompt.</p>}
         </>}
         <details className="wf-advanced" open={advanced} onToggle={event=>setAdvanced(event.currentTarget.open)}><summary>Pengaturan lanjutan (opsional)</summary><p className="wf-muted">Saat dibuka, nama field, ekspresi, dan opsi teknis akan ditampilkan di form ini.</p>{checkbox('disabled','Lewati langkah ini')}{['set','aiAgent'].includes(node.type||'')&&<p className="wf-expression-help">Ekspresi teknis: <code>{'{{ $json.namaField }}'}</code>.</p>}<button disabled={busy} className="wf-danger" onClick={()=>onDelete(node.id)}><Trash2 size={14}/>Hapus langkah</button></details>
      </section>
      <section className={'wf-io '+(tab==='results'?'is-current':'')}><h3>Hasil langkah ini</h3><p className="wf-muted">{result?({success:'Berhasil',simulated:'Pratinjau',error:'Perlu diperbaiki',skipped:'Dilewati',pinned:'Memakai hasil tersimpan',waiting:'Menunggu persetujuan'}[result.status])+' · '+result.durationMs+' ms':isSubNode(node.type)?'Bagian ini digunakan oleh AI Agent. Buka AI Agent untuk melihat hasilnya.':'Klik Uji langkah untuk melihat hasilnya di sini.'}</p>{result?.error&&<p role="alert" className="wf-error">{result.error}</p>}{result?.message&&<p className="wf-inline-note">{result.message}</p>}{!isSubNode(node.type)&&<DataViewer items={result?.output||[]}/>}
        {advanced&&node.type!=='if'&&!isSubNode(node.type)&&<button disabled={busy||(!result?.output.length&&data.pinnedOutput==null)} className="wf-pin-button" onClick={()=>update('pinnedOutput',data.pinnedOutput!=null?null:result?.output)}><Pin size={14}/>{data.pinnedOutput!=null?'Lepas pin data':'Pin output untuk pengujian'}</button>}
        {data.pinnedOutput!=null&&<p className="wf-muted">Pengujian berikutnya memakai data pin, bukan menghitung ulang node ini.</p>}
        {!!result?.input.length&&<details className="wf-advanced"><summary>Bahan yang diterima dari langkah sebelumnya</summary><DataViewer items={result.input}/></details>}
       </section>
      </>}
    </div>
  </aside>
}
